
from flask import Flask,render_template,url_for,request,redirect
import pandas as pd
import numpy as np
app=Flask(__name__)


Indication_info={}
@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template('home.html')



@app.route('/details-for-patient-journey',methods=['GET','POST'])
def details_for_patient_journey(): 
    app.logger.info('details_for_patient_journey function executed')
    global mx_table,rx_table,Diagnosis_Table,Ndc11_Table,Procedure_Table,Indication_info
    if request.method == 'POST':
        app.logger.info('request executed')
        # Get the input values from the form
        Indication_info['Indication'] = request.form.get('Indication')
        # Read MX and RX tables from Excel files
        mx_table = pd.DataFrame(pd.read_excel(request.files['mx_file'], engine='openpyxl'))
        rx_table = pd.DataFrame(pd.read_excel(request.files['rx_file'], engine='openpyxl'))
        Diagnosis_Table = pd.DataFrame(pd.read_excel(request.files['Diagnosis Codes'], engine='openpyxl'))
        Ndc11_Table = pd.DataFrame(pd.read_excel(request.files['NDC11'],engine='openpyxl'))
        Procedure_Table = pd.DataFrame(pd.read_excel(request.files['Procedure Codes'],engine='openpyxl'))

        app.logger.info('MX Table read successfully')
        app.logger.info(f'MX Table shape: {mx_table.shape}')   
        # Store the tables in the patient_info dictionary
        Indication_info['MX Table'] = mx_table
        Indication_info['RX Table'] = rx_table
        Indication_info['Diagnosis Codes'] = Diagnosis_Table
        Indication_info['NDC11'] = Ndc11_Table
        Indication_info['Procedure Codes'] = Procedure_Table
        return redirect(url_for('patient_journey'))
    return render_template('index.html', Indication_info=Indication_info)    
        
    


@app.route('/patient-journey',methods=['GET','POST'])
def patient_journey(): 
      
    # print(f'Mx_table colums: {mx_table.columns}')
    # print(f'Rx_table colums: {rx_table.columns}')
    Diagnosis_Codes=list(Diagnosis_Table['Codes'].astype(str))
    Procedure_codes=list(Procedure_Table['proc_code'].astype(str))
    Ndc11_codes=list(Ndc11_Table['source_product_id'].astype(str))


    mx_table_pat_journey=mx_table[(
            (mx_table['diagnosis_code_1'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_2'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_3'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_4'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_5'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_6'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_7'].isin(list(Diagnosis_Codes))) | 
            (mx_table['diagnosis_code_8'].isin(list(Diagnosis_Codes))))
            & (
            ( mx_table['procedure_code'].isin(list(Procedure_codes))) | 
              (mx_table['ndc11'].isin(list(Ndc11_codes))))][['patient_id','service_date','procedure_code','ndc11']]
    rx_table_pat_journey=rx_table[ (rx_table['diagnosis_code'].isin(list(Diagnosis_Codes))) & (rx_table['ndc11'].isin(list(Ndc11_codes))) & (rx_table['claim_type']=='PD')]
    [['patient_id','service_date','ndc11']]
    # # # #Note: Can add options for claim Status as well in rx
    
    # ##Filter for mx table
    # # mx_table[
    # #     (
            # (mx_table['diagnosis_code_1'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_2'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_3'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_4'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_5'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_6'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_7'].isin(list(Diagnosis_Codes))) | 
            # (mx_table['diagnosis_code_8'].isin(list(Diagnosis_Codes))))
            # & (
            # ( mx_table['procedure_code'].isin(list(Procedure_codes))) | 
            #   (mx_table['ndc11'].isin(list(Ndc11_codes))))]


    # ##Filter for rx table
    #rx_table[ (rx_table['Diagnosis_Code'].isin(Diagnosis_Codes)) & (rx_table['ndc11'].isin(Ndc11_codes)) & (rx_table['Claim_Type']=='PD')]
            
    rx_table_pat_journey['procedure_code']=' '


    union_table = pd.concat([mx_table_pat_journey[['patient_id','service_date','procedure_code','ndc11']], rx_table_pat_journey[['patient_id','service_date','procedure_code','ndc11']]])
    
    union_table['procedure_code'] = union_table['procedure_code'].astype(str)
    union_table['ndc11'] = union_table['ndc11'].astype(str)
    Procedure_Table['proc_code'] = Procedure_Table['proc_code'].astype(str)
    Ndc11_Table['source_product_id'] = Ndc11_Table['source_product_id'].astype(str)


    union_table_proc=pd.merge(union_table,Procedure_Table[['proc_code','mol_name']], how='left', left_on='procedure_code', right_on='proc_code')
    union_table_ndc11=pd.merge(union_table_proc,Ndc11_Table[['source_product_id','product_name']], how='left', left_on='ndc11', right_on='source_product_id')
    

    Final_table=union_table_ndc11[['patient_id','service_date','mol_name','product_name']]
    Final_table['Product']=np.where(Final_table['mol_name'].notnull(), Final_table['mol_name'], Final_table['product_name'])
    Final_table['Indication']='PSO'
    Pat_Journey=Final_table[['patient_id','service_date','Indication','Product']]

    return f"""
        <style>
            body {{ background-color: black; color: white; }}
            table {{ border-collapse: collapse; width: 100%; }}
            th, td {{ border: 1px solid white; padding: 8px; text-align: left; }}
        </style>
        <b>{Indication_info['Indication']} Patient Journey</b><br><br>
        {Pat_Journey.sort_values(by=['patient_id','service_date']).reset_index(drop=True).to_html()}
            """

if __name__=='__main__':
    app.run(debug=True)
